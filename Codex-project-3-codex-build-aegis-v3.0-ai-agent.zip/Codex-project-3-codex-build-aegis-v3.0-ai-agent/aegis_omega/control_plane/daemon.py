from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable


class ControlPlaneDaemon:
    """OpenClaw-style orchestration runtime for 24x7 scheduling."""

    def __init__(self, interval_s: float = 2.0, max_backoff_s: float = 30.0) -> None:
        self.interval_s = interval_s
        self.max_backoff_s = max_backoff_s
        self._running = False

    async def run(self, tick: Callable[[], Awaitable[None]], *, once: bool = False) -> None:
        self._running = True
        current_interval = self.interval_s
        while self._running:
            try:
                await tick()
                current_interval = self.interval_s
            except Exception:
                current_interval = min(current_interval * 2, self.max_backoff_s)
            if once:
                break
            await asyncio.sleep(current_interval)

    def stop(self) -> None:
        self._running = False
