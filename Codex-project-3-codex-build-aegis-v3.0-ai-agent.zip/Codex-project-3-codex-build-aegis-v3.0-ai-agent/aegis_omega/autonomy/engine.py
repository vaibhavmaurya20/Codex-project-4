from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass
from datetime import datetime, timezone

from aegis_omega.agents.hierarchy import AgentRegistry
from aegis_omega.autonomy.planner import GoalPlanner
from aegis_omega.coordination.bus import AgentMessageBus, Message
from aegis_omega.execution.sandbox import ExecutionIsolation
from aegis_omega.execution.virtual_env import VirtualEnvironmentManager
from aegis_omega.governance.policy import GovernanceCore
from aegis_omega.llm_mesh.controller import LLMMeshController
from aegis_omega.memory.store import MemoryStore
from aegis_omega.utils.types import RiskLevel, Task


@dataclass
class AutonomyEngine:
    governance: GovernanceCore
    agent_registry: AgentRegistry
    llm_mesh: LLMMeshController
    memory: MemoryStore
    bus: AgentMessageBus
    execution: ExecutionIsolation
    planner: GoalPlanner
    virtual_envs: VirtualEnvironmentManager
    top_goal: str = "Build robust autonomous software and systems"

    async def evaluate_goals(self) -> list[Task]:
        return self.planner.decompose(self.top_goal)

    async def _execute_task(self, task: Task) -> None:
        owner = self.agent_registry.route(task)
        auth = os.getenv("AEGIS_AUTH_TOKEN")
        decision = self.governance.evaluate_scope(task, authorization_token=auth)
        if not decision.allowed:
            self.memory.failure_memory.append({task.id: decision.reason})
            self.governance.append_audit(f"BLOCKED task={task.id} reason={decision.reason}")
            return

        high_risk = task.risk in {RiskLevel.high, RiskLevel.critical}
        venv = self.virtual_envs.create(task.id, high_risk=high_risk)
        consensus = await self.llm_mesh.parallel_reason(task.goal)
        sandbox = self.execution.prepare(venv.container_runtime, high_risk=high_risk)

        terminal_plan = {
            "mode": "isolated_terminal",
            "runtime": venv.container_runtime,
            "image": venv.image,
            "network_egress": venv.network_egress,
            "host_execution_allowed": sandbox.host_execution_allowed,
            "command_policy": "allowlisted-task-commands-only",
        }

        self.memory.log_execution(
            {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "task_id": task.id,
                "goal": task.goal,
                "owner": owner,
                "decision": decision.reason,
                "consensus": consensus.rationale,
                "warnings": consensus.selected.warnings,
                "sandbox": sandbox.target,
                "virtual_env": str(venv.root),
                "terminal_plan": terminal_plan,
            }
        )
        await self.bus.publish(
            Message(
                topic="tasks.executed",
                sender=owner,
                content=f"{task.goal} -> {consensus.selected.content}",
            )
        )
        self.governance.append_audit(f"EXECUTED task={task.id} owner={owner} env={venv.container_runtime}")

    async def run_cycle(self) -> None:
        tasks = await self.evaluate_goals()
        await asyncio.gather(*(self._execute_task(task) for task in tasks))
