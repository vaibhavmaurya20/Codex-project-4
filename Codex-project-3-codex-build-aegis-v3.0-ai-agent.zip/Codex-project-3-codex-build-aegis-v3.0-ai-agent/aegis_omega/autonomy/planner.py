from __future__ import annotations

from dataclasses import dataclass
from uuid import uuid4

from aegis_omega.utils.types import RiskLevel, Task


@dataclass(slots=True)
class GoalPlanner:
    """Decomposes goals into a parallelizable task graph."""

    def decompose(self, top_goal: str) -> list[Task]:
        goal_lower = top_goal.lower()
        if "linux" in goal_lower or "os" in goal_lower:
            return [
                Task(str(uuid4()), "Design kernel config matrix", "linux", risk=RiskLevel.medium),
                Task(str(uuid4()), "Build packaging pipeline", "devops", risk=RiskLevel.low),
                Task(
                    str(uuid4()),
                    "Run authorized security baseline audit",
                    "security",
                    risk=RiskLevel.medium,
                    requires_authorization=True,
                ),
            ]
        if "cyber" in goal_lower or "penetration" in goal_lower or "vulnerability" in goal_lower:
            return [
                Task(
                    str(uuid4()),
                    "Define authorized assessment scope and targets",
                    "security",
                    risk=RiskLevel.medium,
                    requires_authorization=True,
                ),
                Task(
                    str(uuid4()),
                    "Run non-destructive vulnerability analysis workflow",
                    "security",
                    risk=RiskLevel.high,
                    requires_authorization=True,
                ),
                Task(str(uuid4()), "Generate remediation and patch guidance", "software", risk=RiskLevel.medium),
            ]
        if "research" in goal_lower or "simulation" in goal_lower:
            return [
                Task(str(uuid4()), "Collect related literature", "research", risk=RiskLevel.low),
                Task(str(uuid4()), "Prepare reproducible simulation workflow", "research", risk=RiskLevel.medium),
                Task(str(uuid4()), "Validate outputs with critic model consensus", "research", risk=RiskLevel.medium),
            ]
        return [
            Task(str(uuid4()), "Design architecture", "software", risk=RiskLevel.low),
            Task(str(uuid4()), "Implement core components", "software", risk=RiskLevel.medium),
            Task(str(uuid4()), "Create CI and release automation", "devops", risk=RiskLevel.low),
        ]
