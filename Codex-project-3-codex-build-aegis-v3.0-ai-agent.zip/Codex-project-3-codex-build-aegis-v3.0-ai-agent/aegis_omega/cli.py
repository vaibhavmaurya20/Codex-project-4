from __future__ import annotations

import argparse
import asyncio
from pathlib import Path

from aegis_omega.agents.hierarchy import AgentRegistry
from aegis_omega.autonomy.engine import AutonomyEngine
from aegis_omega.autonomy.planner import GoalPlanner
from aegis_omega.control_plane.daemon import ControlPlaneDaemon
from aegis_omega.coordination.bus import AgentMessageBus
from aegis_omega.execution.sandbox import ExecutionIsolation
from aegis_omega.execution.virtual_env import VirtualEnvironmentManager
from aegis_omega.governance.policy import GovernanceCore
from aegis_omega.llm_mesh.controller import LLMMeshController
from aegis_omega.llm_mesh.providers import ProviderConfig
from aegis_omega.memory.store import MemoryStore


def build_system(top_goal: str) -> tuple[ControlPlaneDaemon, AutonomyEngine]:
    governance = GovernanceCore(audit_log_path=Path("data/audit.log"))
    mesh = LLMMeshController(
        providers=[
            ProviderConfig("openai_compatible", "gpt-architect", "architect", "OPENAI_API_KEY"),
            ProviderConfig("anthropic_compatible", "claude-coder", "coding", "ANTHROPIC_API_KEY"),
            ProviderConfig("local", "llama-fast", "fast", "OLLAMA_API_KEY"),
            ProviderConfig("google_compatible", "gemini-critic", "critic", "GOOGLE_API_KEY"),
            ProviderConfig("openai_compatible", "gpt-security", "security", "OPENAI_API_KEY"),
        ]
    )
    memory = MemoryStore()
    engine = AutonomyEngine(
        governance=governance,
        agent_registry=AgentRegistry(),
        llm_mesh=mesh,
        memory=memory,
        bus=AgentMessageBus(),
        execution=ExecutionIsolation(),
        planner=GoalPlanner(),
        virtual_envs=VirtualEnvironmentManager(),
        top_goal=top_goal,
    )
    daemon = ControlPlaneDaemon(interval_s=2)
    return daemon, engine


async def _async_main(once: bool, top_goal: str) -> None:
    daemon, engine = build_system(top_goal=top_goal)
    await daemon.run(engine.run_cycle, once=once)
    engine.memory.persist_jsonl(Path("data/executions.jsonl"))


def main() -> None:
    parser = argparse.ArgumentParser(description="Run AEGIS-Ω control plane")
    parser.add_argument("--once", action="store_true", help="Run one autonomy cycle")
    parser.add_argument("--goal", default="Build robust autonomous software and systems")
    args = parser.parse_args()
    asyncio.run(_async_main(once=args.once, top_goal=args.goal))


if __name__ == "__main__":
    main()
