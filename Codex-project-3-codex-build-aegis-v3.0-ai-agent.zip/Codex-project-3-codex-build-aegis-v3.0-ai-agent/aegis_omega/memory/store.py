from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class MemoryStore:
    short_term: dict[str, Any] = field(default_factory=dict)
    long_term: dict[str, Any] = field(default_factory=dict)
    execution_history: list[dict[str, Any]] = field(default_factory=list)
    failure_memory: list[dict[str, Any]] = field(default_factory=list)
    tool_memory: dict[str, Any] = field(default_factory=dict)
    collaboration_memory: list[dict[str, Any]] = field(default_factory=list)

    def remember(self, bucket: str, key: str, value: Any) -> None:
        target = getattr(self, bucket)
        if isinstance(target, dict):
            target[key] = value
        else:
            target.append({key: value})

    def log_execution(self, entry: dict[str, Any]) -> None:
        self.execution_history.append(entry)

    def persist_jsonl(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as fp:
            for row in self.execution_history:
                fp.write(json.dumps(row) + "\n")
