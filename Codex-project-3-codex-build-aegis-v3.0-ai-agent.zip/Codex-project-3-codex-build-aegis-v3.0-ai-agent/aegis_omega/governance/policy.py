from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from aegis_omega.utils.types import RiskLevel, Task


@dataclass(slots=True)
class GovernanceDecision:
    allowed: bool
    reason: str


@dataclass
class GovernanceCore:
    audit_log_path: Path
    forbidden_terms: set[str] = field(
        default_factory=lambda: {"host_exec", "unsafe_actuation", "bypass_sandbox"}
    )

    def evaluate_scope(self, task: Task, authorization_token: str | None = None) -> GovernanceDecision:
        if any(term in task.goal.lower() for term in self.forbidden_terms):
            return GovernanceDecision(False, "Action blocked by governance scope policy")

        if task.requires_authorization and not authorization_token:
            return GovernanceDecision(False, "Missing authorization token for sensitive task")

        if task.domain == "security" and task.risk in {RiskLevel.high, RiskLevel.critical}:
            if not authorization_token:
                return GovernanceDecision(False, "Security task requires explicit authorization")

        return GovernanceDecision(True, "Action allowed")

    def append_audit(self, event: str) -> None:
        self.audit_log_path.parent.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).isoformat()
        with self.audit_log_path.open("a", encoding="utf-8") as fp:
            fp.write(f"{stamp} {event}\n")
