from __future__ import annotations

from dataclasses import dataclass, field

from aegis_omega.utils.types import Task


DIRECTORS = [
    "software_architect_agent",
    "linux_os_agent",
    "cybersecurity_agent",
    "research_agent",
    "devops_agent",
    "robotics_agent",
    "vehicle_agent",
    "space_system_agent",
    "self_improvement_agent",
]


@dataclass
class AgentRegistry:
    root_agent: str = "aegis_core"
    directors: list[str] = field(default_factory=lambda: DIRECTORS.copy())

    def route(self, task: Task) -> str:
        mapping = {
            "software": "software_architect_agent",
            "linux": "linux_os_agent",
            "security": "cybersecurity_agent",
            "research": "research_agent",
            "devops": "devops_agent",
            "robotics": "robotics_agent",
            "vehicle": "vehicle_agent",
            "space": "space_system_agent",
        }
        return mapping.get(task.domain, "self_improvement_agent")
