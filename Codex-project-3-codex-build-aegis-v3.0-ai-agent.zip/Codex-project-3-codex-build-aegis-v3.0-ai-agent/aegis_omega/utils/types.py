from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class RiskLevel(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"


@dataclass(slots=True)
class Task:
    id: str
    goal: str
    domain: str
    payload: dict[str, Any] = field(default_factory=dict)
    risk: RiskLevel = RiskLevel.low
    requires_authorization: bool = False
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass(slots=True)
class ModelResponse:
    provider: str
    model: str
    role: str
    content: str
    score: float
    warnings: list[str] = field(default_factory=list)
