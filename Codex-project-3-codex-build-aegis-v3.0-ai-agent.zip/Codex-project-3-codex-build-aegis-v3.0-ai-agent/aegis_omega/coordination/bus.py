from __future__ import annotations

import asyncio
from collections import defaultdict
from dataclasses import dataclass


@dataclass(slots=True)
class Message:
    topic: str
    sender: str
    content: str


class AgentMessageBus:
    def __init__(self) -> None:
        self._topics: dict[str, asyncio.Queue[Message]] = defaultdict(asyncio.Queue)

    async def publish(self, message: Message) -> None:
        await self._topics[message.topic].put(message)

    async def consume(self, topic: str) -> Message:
        return await self._topics[topic].get()
