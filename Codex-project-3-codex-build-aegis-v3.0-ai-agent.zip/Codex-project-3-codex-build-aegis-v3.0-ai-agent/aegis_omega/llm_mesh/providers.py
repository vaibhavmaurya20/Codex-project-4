from __future__ import annotations

import hashlib
from dataclasses import dataclass

from aegis_omega.utils.types import ModelResponse


@dataclass(slots=True)
class ProviderConfig:
    name: str
    model: str
    role: str
    api_key_env: str


class BaseProvider:
    def __init__(self, cfg: ProviderConfig) -> None:
        self.cfg = cfg

    async def infer(self, prompt: str) -> ModelResponse:
        digest = hashlib.sha256(f"{self.cfg.model}:{prompt}".encode()).hexdigest()
        score = (int(digest[:4], 16) % 100) / 100
        content = f"[{self.cfg.role}] {self.cfg.model} synthesized response for: {prompt[:80]}"
        return ModelResponse(
            provider=self.cfg.name,
            model=self.cfg.model,
            role=self.cfg.role,
            content=content,
            score=score,
        )
