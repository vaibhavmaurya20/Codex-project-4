from __future__ import annotations

import asyncio
from dataclasses import dataclass

from aegis_omega.llm_mesh.providers import BaseProvider, ProviderConfig
from aegis_omega.utils.types import ModelResponse


ROLE_WEIGHTS = {
    "architect": 1.2,
    "coding": 1.1,
    "critic": 1.3,
    "security": 1.25,
    "planner": 1.15,
    "fast": 0.9,
}


@dataclass(slots=True)
class ConsensusResult:
    selected: ModelResponse
    candidates: list[ModelResponse]
    rationale: str


class LLMMeshController:
    """Multi-provider, multi-key parallel model orchestrator."""

    def __init__(self, providers: list[ProviderConfig]) -> None:
        self.providers = [BaseProvider(p) for p in providers]

    async def parallel_reason(self, prompt: str) -> ConsensusResult:
        responses = await asyncio.gather(*[p.infer(prompt) for p in self.providers])
        for response in responses:
            if "synthesized" in response.content and len(prompt) < 10:
                response.warnings.append("low-context prompt may degrade quality")

        selected = max(responses, key=lambda r: r.score * ROLE_WEIGHTS.get(r.role, 1.0))
        rationale = (
            f"Selected {selected.provider}/{selected.model} role={selected.role} "
            f"weighted_confidence={(selected.score * ROLE_WEIGHTS.get(selected.role, 1.0)):.2f} "
            f"across {len(responses)} candidates"
        )
        return ConsensusResult(selected=selected, candidates=responses, rationale=rationale)
