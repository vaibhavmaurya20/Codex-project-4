from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class MissionIntent:
    domain: str
    objective: str
    constraints: list[str]


class EmbodimentLayer:
    def validate_for_simulation(self, intent: MissionIntent) -> bool:
        return bool(intent.objective and intent.constraints)

    def to_adapter_payload(self, intent: MissionIntent) -> dict[str, object]:
        return {
            "intent": intent.objective,
            "domain": intent.domain,
            "constraints": intent.constraints,
            "digital_twin_required": True,
        }
