from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class SandboxPlan:
    target: str
    snapshot_required: bool = True
    rollback_on_failure: bool = True
    network_egress: bool = False
    host_execution_allowed: bool = False


class ExecutionIsolation:
    """Execution adapter for Docker/microVM/QEMU targets."""

    def prepare(self, target: str, *, high_risk: bool = False) -> SandboxPlan:
        supported = {"docker", "microvm", "qemu"}
        resolved = target if target in supported else "docker"
        if high_risk:
            return SandboxPlan(target="microvm", network_egress=False, host_execution_allowed=False)
        return SandboxPlan(target=resolved, network_egress=False, host_execution_allowed=False)
