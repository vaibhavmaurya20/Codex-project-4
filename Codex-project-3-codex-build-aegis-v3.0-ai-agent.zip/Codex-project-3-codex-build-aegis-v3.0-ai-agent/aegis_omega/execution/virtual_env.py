from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class VirtualEnvironmentSpec:
    name: str
    root: Path
    container_runtime: str
    image: str
    network_egress: bool
    writable_paths: list[str]


class VirtualEnvironmentManager:
    """Builds isolated virtual Linux execution specs (host-safe, sim-first)."""

    def __init__(self, workspace_root: Path = Path("data/virtual_envs")) -> None:
        self.workspace_root = workspace_root

    def create(self, name: str, *, high_risk: bool = False) -> VirtualEnvironmentSpec:
        env_root = self.workspace_root / name
        env_root.mkdir(parents=True, exist_ok=True)
        runtime = "microvm" if high_risk else "docker"
        image = "aegis/sandbox-secure:latest" if high_risk else "aegis/sandbox-dev:latest"
        spec = VirtualEnvironmentSpec(
            name=name,
            root=env_root,
            container_runtime=runtime,
            image=image,
            network_egress=False,
            writable_paths=["/workspace", "/tmp/aegis"],
        )
        return spec
