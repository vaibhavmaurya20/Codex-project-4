#!/usr/bin/env bash
set -euo pipefail

PYTHON_BIN=${PYTHON_BIN:-python3}

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "python3 is required" >&2
  exit 1
fi

CPU_CORES=$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 2)
MEM_GB=$(awk '/MemTotal/ {printf "%.0f", $2/1024/1024}' /proc/meminfo 2>/dev/null || echo 4)

LIGHTWEIGHT_MODE=false
if [[ "$CPU_CORES" -le 4 || "$MEM_GB" -le 8 ]]; then
  LIGHTWEIGHT_MODE=true
fi

echo "Detected cores=$CPU_CORES mem_gb=$MEM_GB lightweight_mode=$LIGHTWEIGHT_MODE"

"$PYTHON_BIN" -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -e .

mkdir -p data
if [[ ! -f .env ]]; then
  cat > .env <<EOV
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
GOOGLE_API_KEY=
OLLAMA_API_KEY=
EOV
fi

echo "Installation complete. Activate with: source .venv/bin/activate"
