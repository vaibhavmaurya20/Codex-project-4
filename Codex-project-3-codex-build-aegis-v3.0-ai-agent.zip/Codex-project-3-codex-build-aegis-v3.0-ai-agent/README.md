# AEGIS-Ω v3.0

AEGIS-Ω is a runnable, modular autonomous engineering platform that combines:
- Agent Zero-style autonomy and reflection loops
- OpenClaw-style 24x7 orchestration and reliability

## Does AEGIS-Ω use host terminal directly?

No. AEGIS-Ω is designed to create and use **its own isolated virtual Linux execution environments** for task execution planning.
It does not rely on unrestricted host OS command execution. Instead it builds per-task virtual environment specs (Docker/microVM mode) with:
- host execution disabled
- network egress disabled by default
- snapshot/rollback policy
- auditable terminal plans

## What is implemented now

- **Governance-first core** with policy checks, authorization gates, and immutable audit logs
- **Continuous control plane daemon** with retry/backoff behavior for 24x7 operation
- **Multi-LLM mesh controller** supporting concurrent providers, role-weighted consensus, and response warnings
- **Goal planner** that decomposes a top-level objective into a parallel task graph
- **Hierarchical agent routing** (root + directors + worker routing)
- **Parallel execution cycle** using asyncio task fan-out
- **Virtual Linux environment manager** for per-task isolated execution contexts
- **Memory subsystem** with execution/failure/tool/collaboration memory and JSONL persistence
- **Coordination message bus** for agent-to-agent topic communication
- **Execution isolation adapter** for docker/microVM/qemu policies
- **Embodiment abstraction layer** with digital-twin-required intent payloads
- **Linux-friendly installer** with lightweight-mode detection for low-resource systems

## Domain coverage in the current foundation

The runtime can autonomously plan and coordinate workflows for:
- complex software/project development
- Linux OS pipeline work (kernel config, packaging, CI)
- cybersecurity analysis workflows in **authorized** and non-destructive scope
- coding/debugging/test orchestration
- research and simulation workflow preparation

## Quick start

```bash
git clone <repo>
cd Codex-project-3
./install.sh
source .venv/bin/activate
python -m aegis_omega.cli --once --goal "Build a Linux distro CI and security validation stack"
```

Run continuously:

```bash
python -m aegis_omega.cli --goal "Autonomously maintain software platform"
```

## Safety and scope

Priority order:
1. Safety
2. Correctness
3. Coordination
4. Autonomy
5. Speed

Sensitive domains (e.g., security workflows) require explicit authorization tokens and are blocked by default.

## Repository layout

```text
aegis_omega/
  governance/      # safety policies + audit
  control_plane/   # 24x7 scheduling and resilience
  autonomy/        # planning + autonomous run loop
  llm_mesh/        # parallel multi-provider reasoning + consensus
  agents/          # root and director routing
  memory/          # multi-tier memory + persistence
  coordination/    # message bus and sync
  execution/       # sandbox planning/isolation + virtual env specs
  embodiment/      # intent abstraction and sim-first constraints
  cli.py
configs/
  default.yaml
tests/
install.sh
```
