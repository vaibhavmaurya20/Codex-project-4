import os
from pathlib import Path

from aegis_omega.agents.hierarchy import AgentRegistry
from aegis_omega.autonomy.engine import AutonomyEngine
from aegis_omega.autonomy.planner import GoalPlanner
from aegis_omega.coordination.bus import AgentMessageBus
from aegis_omega.execution.sandbox import ExecutionIsolation
from aegis_omega.execution.virtual_env import VirtualEnvironmentManager
from aegis_omega.governance.policy import GovernanceCore
from aegis_omega.llm_mesh.controller import LLMMeshController
from aegis_omega.llm_mesh.providers import ProviderConfig
from aegis_omega.memory.store import MemoryStore


async def _run_cycle(tmp_path: Path, goal: str) -> MemoryStore:
    governance = GovernanceCore(audit_log_path=tmp_path / "audit.log")
    mesh = LLMMeshController(
        [
            ProviderConfig("test", "m1", "planner", "K1"),
            ProviderConfig("test", "m2", "critic", "K2"),
            ProviderConfig("test", "m3", "security", "K3"),
        ]
    )
    memory = MemoryStore()
    engine = AutonomyEngine(
        governance=governance,
        agent_registry=AgentRegistry(),
        llm_mesh=mesh,
        memory=memory,
        bus=AgentMessageBus(),
        execution=ExecutionIsolation(),
        planner=GoalPlanner(),
        virtual_envs=VirtualEnvironmentManager(workspace_root=tmp_path / "venvs"),
        top_goal=goal,
    )
    await engine.run_cycle()
    return memory


def test_autonomy_cycle_executes_parallel_tasks(tmp_path):
    import asyncio

    memory = asyncio.run(_run_cycle(tmp_path, "build software platform"))
    assert len(memory.execution_history) == 3


def test_sensitive_tasks_block_without_authorization(tmp_path):
    import asyncio

    os.environ.pop("AEGIS_AUTH_TOKEN", None)
    memory = asyncio.run(_run_cycle(tmp_path, "build linux os"))
    assert len(memory.failure_memory) >= 1


def test_sensitive_tasks_execute_with_authorization(tmp_path):
    import asyncio

    os.environ["AEGIS_AUTH_TOKEN"] = "approved"
    memory = asyncio.run(_run_cycle(tmp_path, "build linux os"))
    assert len(memory.execution_history) >= 1


def test_virtual_environment_spec_is_persisted_in_execution(tmp_path):
    import asyncio

    os.environ["AEGIS_AUTH_TOKEN"] = "approved"
    memory = asyncio.run(_run_cycle(tmp_path, "cybersecurity vulnerability analysis"))
    assert len(memory.execution_history) >= 1
    assert "virtual_env" in memory.execution_history[0]
    assert memory.execution_history[0]["terminal_plan"]["host_execution_allowed"] is False
